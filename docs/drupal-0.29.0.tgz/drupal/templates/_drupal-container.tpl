{{/* Drupal container spec */}}
{{ define "common.deployment.lifecyle.preStop" }}
exec:
  command: ["sleep", {{ .Values.gracefulUpdate.preStopTimeout | default "15" | quote }}]
{{- end }}

{{ define "drupal.deployment.containerSpec" }}
{{ include "drupal.commonSpec" . -}}
  lifecycle:
    preStop:
    {{- include "common.deployment.lifecyle.preStop" . | indent 6 }}
  {{- if not (.Values.drupalStartupProbe | empty) }}
  startupProbe:
    {{- toYaml .Values.drupalStartupProbe | nindent 4 }}
  {{- end }}
  {{- if not (.Values.drupalLivenessProbe | empty) }}
  livenessProbe:
    {{- toYaml .Values.drupalLivenessProbe | nindent 4 }}
  {{- else }}
  livenessProbe:
    tcpSocket:
      port: fastcgi-health
    initialDelaySeconds: 5
    periodSeconds: 10
    timeoutSeconds: 5
    failureThreshold: 8
  {{- end }}
  {{- if not (.Values.drupalReadinessProbe | empty) }}
  readinessProbe:
    {{- toYaml .Values.drupalReadinessProbe | nindent 4 }}
  {{- else }}
  readinessProbe:
    tcpSocket:
      port: fastcgi-health
    initialDelaySeconds: 5
    periodSeconds: 10
    timeoutSeconds: 5
    failureThreshold: 8
  {{- end }}
  # @todo: Remove this, add "resources" instead and allow people to add what they want.
  resources:
  {{- if eq (._isFrontend | default false) true }}
  {{- include "drupal.frontend.resources" . | indent 4 }}
  {{- else }}
  {{- include "drupal.app.resources" . | indent 4 }}
  {{- end }}
{{ end }}
{{ define "drupal.cron.containerSpec" }}
{{ include "drupal.commonSpec" . -}}
  command: ["/bin/bash"]
  args:
    - "-c"
    - {{ include "drupal.cron.commandArg" . }}
  resources:
  {{- include "drupal.cron.resources" . | indent 4 }}
{{ end }}

{{- define "drupal.cron.commandArg" -}}
{{- if not (.Values.drupalCronJob | empty) -}}
{{ .Values.drupalCronJob.commandArg | default "drush cron" | quote }}
{{- else -}}
"drush cron"
{{- end -}}
{{- end -}}

{{ define "drupal.backupJob.containerSpec" -}}
{{ include "drupal.commonSpec" . -}}
  # @todo: Chugging it into some object storage like minio would be better probably.
  command: ["/bin/bash"]
  args:
    - "-c"
    - |
      cd /backups || exit 1
      KEEP={{ include "drupal.backupJob.keep" . }}
      STAMP=$(date +%F_%H-%M-%S)
      FILE="db-backup.${STAMP}.sql.gz"
      # Timestamped dumps, newest first. Manual dumps and "latest" are never touched.
      dumps() { ls -1t db-backup.[0-9]*.sql.gz 2>/dev/null; }
      # Empty files are leftovers of runs that ran out of space.
      find . -maxdepth 1 -name 'db-backup.[0-9]*.sql.gz' -size 0 -delete
      # Make room for the new dump and its "latest" copy, sized by the newest
      # dump plus a margin. This keeps fewer than KEEP dumps on a small volume.
      LAST=$(dumps | head -n 1)
      if [ -n "${LAST}" ]; then
        NEED_KB=$(( $(wc -c < "${LAST}") / 1024 * 22 / 10 ))
        while [ "$(df -Pk . | awk 'NR==2 {print $4}')" -lt "${NEED_KB}" ]; do
          OLDEST=$(dumps | tail -n 1)
          [ -n "${OLDEST}" ] || break
          echo "Low on space, removing ${OLDEST}"
          rm -f -- "${OLDEST}"
        done
      fi
      if drush sql-dump --result-file="/backups/db-backup.${STAMP}.sql" --gzip && [ -s "${FILE}" ]; then
        cp "${FILE}" db-backup.latest.sql.gz || exit 1
        dumps | tail -n +$(( KEEP + 1 )) | while read -r OLD; do
          echo "Retention (keep ${KEEP}), removing ${OLD}"
          rm -f -- "${OLD}"
        done
      else
        rm -f -- "${FILE}" "db-backup.${STAMP}.sql"
        exit 1
      fi
  resources:
  {{- include "drupal.backupJob.resources" . | indent 4 }}
{{ end }}

{{- define "drupal.backupJob.keep" -}}
{{- if not (.Values.drupalBackupJob | empty) -}}
{{ .Values.drupalBackupJob.keep | default 5 | int }}
{{- else -}}
5
{{- end -}}
{{- end -}}

{{ define "drupal.preUpgradeJob.containerSpec" -}}
{{ include "drupal.commonSpec" . -}}
  command: ["/bin/bash"]
  args:
    - "-c"
    - {{ include "drupal.preUpgrade.commandArg" . }}
  resources:
  {{- include "drupal.preUpgradeJob.resources" . | indent 4 }}
{{ end }}

{{- define "drupal.preUpgrade.commandArg" -}}
{{- if not (.Values.drupalPreUpgradeJob | empty) -}}
{{ .Values.drupalPreUpgradeJob.commandArg | default "drush state:set purge.disable 1 && drush state:set exception_mailer.enabled 0" | quote }}
{{- else -}}
"drush state:set purge.disable 1 && drush state:set exception_mailer.enabled 0"
{{- end -}}
{{- end -}}

{{- define "drupal.backupRestoreJob.backupFile" -}}
/backups/db-backup.{{- .Values.rollback.backupVersion | default "latest" -}}.sql
{{- end -}}

{{ define "drupal.backupRestoreJob.containerSpec" -}}
{{ include "drupal.commonSpec" . -}}
  command: ["/bin/bash"]
  args:
    - "-c"
    - "gunzip -fk {{ include "drupal.backupRestoreJob.backupFile" . -}}.gz && cd /var/www/html && drush sql:drop -y && drush sqlc < {{ include "drupal.backupRestoreJob.backupFile" . }} && rm {{ include "drupal.backupRestoreJob.backupFile" . -}}"
  resources:
  {{- include "drupal.backupRestoreJob.resources" . | indent 4 }}
{{ end }}

{{ define "drupal.deployJob.containerSpec" -}}
{{ include "drupal.commonSpec" . -}}
  command: ["/bin/bash"]
  args:
    - "-c"
    - {{ include "drupal.deploy.commandArg" . }}
  resources:
  {{- include "drupal.deployJob.resources" . | indent 4 }}
{{ end }}

{{- define "drupal.deploy.commandArg" -}}
{{- if not (.Values.drupalDeployJob | empty) -}}
{{ .Values.drupalDeployJob.commandArg | default "drush deploy" | quote }}
{{- else -}}
"drush deploy"
{{- end -}}
{{- end -}}

{{ define "drupal.commonSpec" }}
- image: {{ .Values.drupalImage }}
  imagePullPolicy: {{ .Values.imagePullPolicy }}
  name: drupal
  {{/* @todo: Add and test these for enchanced security.
  @todo: Add the equivalent to the nginx image.
  @todo: Allow controlling these via values.yaml
  securityContext:
    privileged: false
    allowPrivilegeEscalation: false
    runAsNonRoot: true
    runAsUser: 1000
    runAsGroup: 1000
  */}}
  #@todo: In a rolling update this is going to break some containers (new db -> old code).
  #@todo: Rollback is also not possible (db is gonna stay the same).
  env:
  - name: DRUPAL_DATABASE_HOST
    valueFrom:
      configMapKeyRef:
        name: {{ .Values.global.project }}-{{ .Values.global.environment }}-app
        key: database.host
  - name: DRUPAL_DATABASE_PORT
    valueFrom:
      configMapKeyRef:
        name: {{ .Values.global.project }}-{{ .Values.global.environment }}-app
        key: database.port
  - name: DRUPAL_DATABASE_USERNAME
    valueFrom:
      secretKeyRef:
        name: {{ .Values.global.project }}-{{ .Values.global.environment }}-database
        key: mariadb-username
  - name: DRUPAL_DATABASE_PASSWORD
    valueFrom:
      secretKeyRef:
        name: {{ .Values.global.project }}-{{ .Values.global.environment }}-database
        key: mariadb-password
  - name: DRUPAL_DATABASE_NAME
    valueFrom:
      secretKeyRef:
        name: {{ .Values.global.project }}-{{ .Values.global.environment }}-database
        key: mariadb-db-name
  - name: DRUPAL_HASH_SALT
    valueFrom:
      secretKeyRef:
        name: {{ .Values.global.project }}-{{ .Values.global.environment }}-app-settings
        key: drupal-hash-salt
  - name: DRUSH_BASE_URI
    valueFrom:
      configMapKeyRef:
        name: {{ .Values.global.project }}-{{ .Values.global.environment }}-app
        key: drush-site-uri
  - name: DRUPAL_BASE_URI
    valueFrom:
      configMapKeyRef:
        name: {{ .Values.global.project }}-{{ .Values.global.environment }}-app
        key: drupal-base-uri
  - name: FCGI_CONNECT
    value: "127.0.0.1:{{ .Values.drupalFpmHealthPort | default 9000 }}"
  {{- if eq .Values.solr.enable true }}
  - name: SOLR_HOST
    valueFrom:
      configMapKeyRef:
        name: {{ include "app.solrConfName" . | trim }}
        key: host
  - name: SOLR_CORE
    valueFrom:
      configMapKeyRef:
        name: {{ include "app.solrConfName" . | trim }}
        key: core
  - name: TIKA_SERVER_HOST
    valueFrom:
      configMapKeyRef:
        name: {{ include "app.solrConfName" . | trim }}
        key: tika-server
  {{- if eq .Values.solr.authenticate true }}
  - name: SOLR_USERNAME
    valueFrom:
      secretKeyRef:
        name: {{ include "app.solrSecretName" . | trim }}
        key: username
  - name: SOLR_PASSWORD
    valueFrom:
      secretKeyRef:
        name: {{ include "app.solrSecretName" . | trim }}
        key: password
  {{- end }}
  {{- end }}
  {{- if eq (.Values.redis.enable | default false) true }}
  - name: REDIS_HOST
    valueFrom:
      configMapKeyRef:
        name: {{ include "app.redisConfName" . | trim }}
        key: host
  {{- if eq .Values.redis.authenticate true }}
  - name: REDIS_PASSWORD
    valueFrom:
      secretKeyRef:
        name: {{ include "app.redisSecretName" . | trim }}
        key: password
  {{- end }}
  {{- end }}
  {{/* @todo: Handle duplicated env vars. */}}
  {{- if eq (._isFrontend | default false) true -}}
  {{- if not (.Values.dedicatedFrontend.drupalExtraEnvVars | empty) -}}
  {{ toYaml .Values.dedicatedFrontend.drupalExtraEnvVars | nindent 2 }}
  {{- end }}
  {{- end }}
  {{- if not (.Values.drupalExtraEnvVars | empty) -}}
  {{ toYaml .Values.drupalExtraEnvVars | nindent 2 }}
  {{- end }}
  {{/* @todo: Handle duplicated env vars. */}}
  {{- if eq (._isJob | default false) true -}}
  {{- if not (.Values.jobExtraEnvVars | empty) -}}
  {{ toYaml .Values.jobExtraEnvVars | nindent 2 }}
  {{- end }}
  {{- end }}
  ports:
  - name: fastcgi
    containerPort: {{ .Values.drupalFpmPort | default 9000 }}
    protocol: TCP
  - name: fastcgi-health
    containerPort: {{ .Values.drupalFpmHealthPort | default 9000 }}
  volumeMounts:
  {{- include "common.mounts" . | indent 2 -}}
  {{- if eq (._isJob | default false) false -}}
  {{- if eq (._isFrontend | default false) true -}}
  {{- include "drupalFrontend.robots.mounts" . | nindent 2 }}
  {{ else }}
  {{- include "drupal.robots.mounts" . | nindent 2 }}
  {{- end }}
  {{- end }}
  {{- include "drupal.mounts" . | indent 2 -}}
{{ end }}

{{ define "drupal.frontend.resources" }}
requests:
  cpu: {{ .Values.dedicatedFrontend.resources.drupalCpuRequest | default "10m" | quote }}
  memory: {{ .Values.dedicatedFrontend.resources.drupalMemoryRequest | default "32Mi" | quote }}
limits:
  cpu: {{ .Values.dedicatedFrontend.resources.drupalCpuLimit | default "200m" | quote }}
  memory: {{ .Values.dedicatedFrontend.resources.drupalMemoryLimit | default "256Mi" | quote }}
{{ end }}

{{ define "drupal.app.resources" }}
requests:
  cpu: {{ .Values.drupalCpuRequest | default "10m" | quote }}
  memory: {{ .Values.drupalMemoryRequest | default "32Mi" | quote }}
limits:
  cpu: {{ .Values.drupalCpuLimit | default "800m" | quote }}
  memory: {{ .Values.drupalMemoryLimit | default "512Mi" | quote }}
{{ end }}

{{ define "drupal.job.resources" }}
requests:
  cpu: {{ .Values.jobCpuRequest | default "10m" | quote }}
  memory: {{ .Values.jobMemoryRequest | default "32Mi" | quote }}
limits:
  cpu: {{ .Values.jobCpuLimit | default "1000m" | quote }}
  memory: {{ .Values.jobMemoryLimit | default "2048Mi" | quote }}
{{ end }}

{{ define "drupal.cron.resources" }}
{{- include "drupal.job.resources" . }}
{{ end }}

{{ define "drupal.backupJob.resources" }}
{{- include "drupal.job.resources" . }}
{{ end }}

{{ define "drupal.preUpgradeJob.resources" }}
{{- include "drupal.job.resources" . }}
{{ end }}

{{ define "drupal.deployJob.resources" }}
{{- include "drupal.job.resources" . }}
{{ end }}

{{ define "drupal.backupRestoreJob.resources" }}
{{- include "drupal.job.resources" . }}
{{ end }}
